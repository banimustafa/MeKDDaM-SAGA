# MekDDaM-SAGA

Requirements:
=============
This software works on JDK Java 6.0

Note: You can install different java versions in multiple homes. But you have to change the
environment path to point to the installation that you want to be set as a default version
on your system.
